
function Features=DMFS(X,s,q)
%%Texture descriptor with Wavelet and wavelet leaders-based DMFS
%%Code by: Man Liu
%%email: lmdyne@163.com

% The procedure DFA=DMFS(X,s,q)
% is used to directly calculate the multifractal properties of two-dimensional
% multifractal measures.
%
% Input:
%   X: the two-dimensional image we considered.
%   s:partition scale
%   q: multifractal order
%
% Output:
%   Features:Alpha/Falpha

for i=1:length(s)
    [xsize,ysize]=size(X);
    lgth=s(i);
    Mrx=fix(xsize/lgth);
    Mry=fix(ysize/lgth);
    Y = zeros(Mrx,Mry);
   diffMatrix = zeros(s(i)*s(i),Mrx*Mry); 
   diffMMSE=[];
    a=[]; b=[];
    a=[a;1:lgth];
    b = repmat(a, lgth, 1);
    b1 = reshape(b, 1, numel(b));
    b2 = reshape(b',1, numel(b'));
    w=0;
    for j=1:Mrx
        for k=1:Mry   
            Z=X((j-1)*lgth+1:j*lgth,(k-1)*lgth+1:k*lgth);
            Z1=(cumsum((cumsum(Z))'));
            G=Z1(:);
            r=[b1' b2' ones(size(G))];
            [rb,rbint,rr,rrint,rstats]=regress(G(:),r);
            Y(j,k)=sqrt(mean(rr.^2));
        end
    end
        % Estimate the root-mean-square function F
    F{i}=Y;    
end 

Alpha=[];
Falpha=[];
Fa=[];
Ffa=[];
for q_i = 1:length(q) 
    ta=[];
    for j=1:length(F)
        f=F{j}(:);
        u1=power(f,q(q_i));
         u=u1./sum(u1);  
         Fa(j,q_i)=sum(u .* log(f));
         Ffa(j,q_i)=sum(u .* log(u));
    end
    
     line = polyfit(log(s'),Fa(:,q_i),1);
     Alpha(q_i) = line(1);
     line = polyfit(log(s'),Ffa(:,q_i),1);
     Falpha(q_i) = line(1);
end
figure,plot(Alpha,Falpha,'.k-'), grid on,xlabel('\alpha','Fontname', 'Times New Roman'),ylabel('f(\alpha)','Fontname', 'Times New Roman');
Features=[];s=1;
Features=[];
[Features(1) fm]=max(Alpha);
Features(2)=Falpha(fm);
[Features(3) fm]=min(Alpha);
Features(4)=Falpha(fm);
[Features(6) fx]=max(Falpha);
Features(5)=Alpha(fx);








