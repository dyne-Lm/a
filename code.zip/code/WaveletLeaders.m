%%Texture descriptor with Wavelet and wavelet leaders-based DMFS
%%Code by: Man Liu
%%email: lmdyne@163.com
function Wl= WaveletLeaders(X)
    Wl={};
    t=1;
    for s=1:3
       [ca,ch,cv,cd] = dwt2(X,'db2');
        D1=abs(max(max(ch,cv),cd));
      
        X=ca;
        if t==1
            Wl{t}=ca;
            D=D1;
        else
             D=leader(D,D1);
        end
        
        
        t=t+1;Wl{t}=ch;
        t=t+1;Wl{t}=cv;
        t=t+1;Wl{t}=cd;
        t=t+1;Wl{t}=D;
    end
    
    function Wleader=leader(X1,X2)
          [xsize,ysize]=size(X2);%��ͼ��߳�
          [xsize1,ysize1]=size(X1);
          Wleader=X2;
          for i=1:xsize
              for j=1:ysize
                  ai=i*2;
                  bi=j*2;
                  if ai <= xsize1 & bi<= ysize1
                      A=X1(ai-1:ai,bi-1:bi);
                      a=max(max(A));
                      Wleader(i,j)=max(a,X2(i,j));
                  end
              end
          end
    end
end