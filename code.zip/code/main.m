%%Texture descriptor with Wavelet and wavelet leaders-based DMFS
%%Code by: Man Liu
%%email: lmdyne@163.com
clear all;
close all;
clc;
 
maindir = 'images';%the folder in which image files exists
subdir =  dir( maindir );   % Determine subfolders
s=0;
l=0; 
q=(-6:0.5:6);
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' ) || ...
        isequal( subdir( i ).name, '..' ) || ...
        ~subdir( i ).isdir )   % jump if the subfolder is not a directory
        continue;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reading all images from a current subfolder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    subdirpath = fullfile( maindir, subdir( i ).name, '*.bmp' );
    images = dir( subdirpath );  
    s=s+1;
   
    for k = 1 : length( images )
        imagepath = fullfile( maindir, subdir( i ).name, images( k ).name  )
        Y = imread( imagepath );  
        X=Y(:,:,1);
        X=double(X);
        wl= WaveletLeaders(X);%Wavelet Coefficient Matrix with Waveletleaders
        %wl= WaveletOutLeaders(X);%Wavelet Coefficient Matrix without Waveletleaders
        WMFS={};
        
        for j=1:length(wl) 
        Xdma=wl{j};
        u=fix(min(size(Xdma))/2);
        S=(6:2:u); 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The multifractal spectrum based on the direct MF-DFA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        DMA = DMFS(Xdma,S,q);        
        WMFS{j}=DMA ;
        end
    end
end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate Wavelet Coefficient Matrix without Waveletleaders
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Wl= WaveletOutLeaders(X)
    Wl={};
    t=1;
    for s=1:3
       [ca,ch,cv,cd] = dwt2(X,'db2');
        X=ca;
        if t==1
            Wl{t}=ca;
        end
        t=t+1;Wl{t}=ch;
        t=t+1;Wl{t}=cv;
        t=t+1;Wl{t}=cd;
    end
end

